import { Directive } from '@angular/core';

@Directive({
  selector: '[appShoppinglist]'
})
export class ShoppinglistDirective {

  constructor() { }

}
