import { ShoppinglistDirective } from './shoppinglist.directive';

describe('ShoppinglistDirective', () => {
  it('should create an instance', () => {
    const directive = new ShoppinglistDirective();
    expect(directive).toBeTruthy();
  });
});
