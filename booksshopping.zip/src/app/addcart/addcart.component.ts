import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-addcart',
  templateUrl: './addcart.component.html',
  styleUrls: ['./addcart.component.scss']
})
export class AddcartComponent implements OnInit {

  // @Input() valu:any[] =[]
  // @Input() getdata:any
  carddata:any[] = [];
  data:any[] = [];
  constructor(public http:HttpClient) { }

  ngOnInit(): void {
    this.updatedata(this.carddata)
  }
  updatedata(obj:any){
    this.carddata = obj;
    this.data = this.carddata
   // this.http.get()
    console.log(this.carddata);
    
  }


}
