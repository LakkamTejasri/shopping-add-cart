import { Component, OnInit, Input, Output, EventEmitter,ViewChild } from '@angular/core';
import { PagetitleService } from '../pagetitle.service';
import { Router } from '@angular/router';
import{AddcartComponent} from '../addcart/addcart.component'


@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit{

  searchText:any;
  @Input() categories:any;
  // @Input() addcartdata:any;
  @ViewChild(AddcartComponent) cartcomponent!:AddcartComponent
  // @Output() addcartdata = new EventEmitter();

 
 
  constructor(public router:Router) { }

  ngOnInit(): void {
    // this.cartcomponent.updatedata.subscribe(()=>{})
  }
  add_cart(data:any){
    this.cartcomponent.updatedata(data)
    // this.router.navigateByUrl('/addcart')
    // console.log(data)
    // this.addcartdata.emit(data)
    // this.addcartdata = data
    //  console.log(this.addcartdata)
    // this.router.navigateByUrl('/addcart')
  }


}
